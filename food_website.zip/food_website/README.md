# html-css-basics
This repo has simple programs for beginners to create a Food recipe webpage using HTML and CSS.
